﻿# HR v1 (Policy E vs Full T=5000)

## Policy (congelada)
b1=300, b2=3000, Tmin=2000, Tmid=3000, Thigh=5000  (base de ceros: canonical_idxgamma_T10000.txt)

## Calidad (ratios)


File     : .\results\HR_v1\hr_policy_v1.csv
Points   : 1949
Median   : 0,0001262449565453
P90      : 0,0004423348608713
P95      : 0,001614537493417
Mean     : 0,000394995122429789
MaxRatio : 0,0107991659677






File     : .\results\HR_v1\hr_full_T5000_v1.csv
Points   : 1949
Median   : 0,0001049731101648
P90      : 0,0004035781825418
P95      : 0,001650371518909
Mean     : 0,000376626329841748
MaxRatio : 0,01083826980824





## Coste
T_used distribution:
 5000  1261  64,7 %
 3000   500  25,7 %
 2000   188  9,6 %

Ceros medios por x ≈ 3704  (vs k(5000)=4520)
Ahorro vs T=5000 ≈ 18 %

